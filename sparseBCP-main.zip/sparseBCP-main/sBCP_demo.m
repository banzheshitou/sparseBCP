% Demo script
% Uncomment each case to see the results 

src = im2double(imresize(imread('test_imgs/2015_00003.png'),1));
para.lambda = 1e-4; 
para.dark_r = 5; 
para.derta  = 0.101;
para.gamV   = 0.3;
[Iout] = sBCP_main(src, para);
figure;imshow([src Iout]);title('src Iout');


% % 112.png 
% src = im2double(imresize(imread('test_imgs/112.png '),1)); 
% para.lambda = 1e-5; 
% para.dark_r = 5; 
% para.derta  = 0.101;
% para.gamV   = 0.3;
% [Iout] = sBCP_main(src, para);
% figure;imshow([src Iout]);title('src Iout');


% % 235.png
% src = im2double(imresize(imread('test_imgs/235.png '),1)); 
% para.lambda = 1e-4; 
% para.dark_r = 5; 
% para.derta  = 1.101;
% para.gamV   = 0.3;
% [Iout] = sBCP_main(src, para);
% figure;imshow([src Iout]);title('src Iout');

% %780.png
% src = im2double(imresize(imread('test_imgs/780.png '),1)); 
% para.lambda = 1e-5; 
% para.dark_r = 5; 
% para.derta  = 0.101;
% para.gamV   = 0.3;
% [Iout] = sBCP_main(src, para);
% figure;imshow([src Iout]);title('src Iout');
